﻿namespace LoginandRegistration.Models.DTO
{
    public class AdminDTO :Admin
    {

        public string? PasswordClear { get; set; }

    }
}
